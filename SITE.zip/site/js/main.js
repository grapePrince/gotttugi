$(function() {

    $('.sliderWrap').bxSlider();



}); // end of file